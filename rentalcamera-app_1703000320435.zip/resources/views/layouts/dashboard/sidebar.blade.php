  <!-- ======= Sidebar ======= -->
  <aside id="sidebar" class="sidebar">

    <ul class="sidebar-nav" id="sidebar-nav">
      {{-- @if (auth()->guard('web')->check()) 
        <li class="nav-item">
          <a href="{{ route('home.index') }}" class="nav-link {{ request()->routeIs('user.home.index') ? '' : 'collapsed' }}">
              <i class="bi bi-grid"></i>
              <span>Dashboard</span>
          </a>
      </li>
     @endif --}}
     @if (auth()->guard('admin')->check()) 
        <li class="nav-item">
          <a href="{{ route('admin.home') }}" class="nav-link {{ request()->routeIs('admin.home.index') ? '' : 'collapsed' }}">
              <i class="bi bi-grid"></i>
              <span>Dashboard</span>
          </a>
      </li>
     @endif
     
  </aside><!-- End Sidebar-->
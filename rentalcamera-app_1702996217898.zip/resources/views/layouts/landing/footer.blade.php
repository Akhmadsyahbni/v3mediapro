<section class="footer">
    <div class="box-container">
        <div class="box">
            <h3>quick links</h3>
            <a href="#"><i class="fa fa-arrow-right"></i> home</a>
            <a href="#"><i class="fa fa-arrow-right"></i> About</a>
            <a href="#"><i class="fa fa-arrow-right"></i> Camera</a>
            <a href="#"><i class="fa fa-arrow-right"></i> Services</a>
            <a href="#"><i class="fa fa-arrow-right"></i> Contact</a>
        </div>
        <div class="box">
            <h3>extra links</h3>
            <a href="#"><i class="fa fa-arrow-right"></i> my order</a>
            <a href="#"><i class="fa fa-arrow-right"></i> my favirate</a>
            <a href="#"><i class="fa fa-arrow-right"></i> best product</a>
            <a href="#"><i class="fa fa-arrow-right"></i> new arrival</a>
            <a href="#"><i class="fa fa-arrow-right"></i> tearms or use</a>
        </div>
        <div class="box">
            <h3>follow us</h3>
            <a href="#"><i class="fa fa-facebook"></i> facebook</a>
            <a href="#"><i class="fa fa-twitter"></i> twitter</a>
            <a href="#"><i class="fa fa-instagram"></i> instagram</a>
            <a href="#"><i class="fa fa-linkedin"></i> linkedin</a>
            <a href="#"><i class="fa fa-telegram"></i> telegram</a>
        </div>
        <div class="box">
            <h3>newsletter</h3>
            <p>subscribe for latest updates</p>
            <form action="">
                <input type="email" placeholder="enter your email">
                <input type="submit" value="subscribe" class="btn">
            </form>
            <img src="img/payment.png" alt="" class="payment">
        </div>
    </div>
</section>